from setuptools import setup, find_packages


setup (
    name='mjson',
    version='0.1dev',
    description='Convenient "python -mjson.tools"',
    author='kjirou',
    author_email='sorenariblog@gmail.com',
    url='http://blog.kjirou.net/',
    packages=find_packages(),
)
